<style>
.header{
background-color: black !important;
}

</style>

<div class="js-smooth-scroll bg-light-1" id="page-wrapper" data-barba="container">
    <main class="page-wrapper__content">    
        <section>
            <div class="container">
                <div class="main" style="min-height:30vh;"></div>
            </div>
        </section>
    </main>